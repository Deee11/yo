# Mizuhara-Chizuru-AI-Discord-Bot
Mizuhara Chizuru Anime character's AI. based on the jailbroken version of Bing AI. (https://github.com/juzeon/SydneyQt/tree/v1)

**Most Interesting Commands:**

You can talk to the AI powered bot. Just by Taggnig the bot. or replying to its messages. Or simply in the dms.


```
/doubt
```

- Ask a question directly to Bing AI. You can even send images for clarification!

```
/create_image
```

-  Generate an AI-generated image from text. Powered by Bing Image Creator, but faster than using the website.

**Most Useful Commands:**

```
/mystats
```

- Check your today's time spent in the study room with video or screen share on.

```
/allstats
```

- View the study stats of all members in the server for all time.

```
/todaystats
```

- See the study stats of all members in the server for today.

```
/timerr
```

- Set a timer for a specified number of minutes.

```
/state
```

- Check if your study time is being recorded. (It's only recorded when your camera or screen is on.)

```
/allstates
```

- See the current state of everyone in the server.

**Additional Information:**

- Other commands are either developer-only, undeveloped, or useless. These were added for debugging purposes.
- The bot is still under development, so expect new and improved features in the future! 


**Some examples of personality Zero (GF mode, that will share its opinions. and will refuse to acknowledge it's an AI):- **

![image](https://github.com/estrizal/Mizuhara-Chizuru-AI-Discord-Bot/assets/87994109/e6e4557a-b186-45c4-8e15-3560c52ee1a3)


![image](https://github.com/estrizal/Mizuhara-Chizuru-AI-Discord-Bot/assets/87994109/2ee5fc0f-3831-47ea-9121-6adce6f778b1)

**Examples of personality 1:- Overall MORE DETAILED. Answers. Will never get into controversies. more professional and smart.:- **
![image](https://github.com/estrizal/Mizuhara-Chizuru-AI-Discord-Bot/assets/87994109/a3843f6e-ac69-4e4f-88ec-c53f4fc6b4c6)

**Example of personality 2:- Bing AI powered. SUPERRRR SLOWWWWW. But Most Accurate. Use /doubt to ask you query with an image too. doing /doubt automatically shifts personality to 2. :- **
It has internet access. so you can get latest info. Like yesterday's news.
![image](https://github.com/estrizal/Mizuhara-Chizuru-AI-Discord-Bot/assets/87994109/945542c0-9225-4250-9437-920df58e30b5)

**Whenever You upload an image, it shifts to personality 3 and answers your query regarding the  image. (you gotta manually shift her mode, as 3 is only meant for image queries. :- **

![image](https://github.com/estrizal/Mizuhara-Chizuru-AI-Discord-Bot/assets/87994109/9f87d113-c735-4277-a522-04df49da1d1b)

**Credits:- ** 
* ReEdgeGPT - https://github.com/Integration-Automation/ReEdgeGPT
* SydneyQT - https://github.com/juzeon/SydneyQt/tree/v1
